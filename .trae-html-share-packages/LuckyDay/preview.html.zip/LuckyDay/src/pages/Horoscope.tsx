import { useState, useEffect, useRef } from 'react'
import PageWrapper from '../components/PageWrapper'
import { zodiacSigns, getElementBgColor, type ZodiacSign } from '../data/zodiac'
import { fetchHoroscope, type HoroscopeData, type FortuneScores } from '../api/horoscope'
import Chart from 'chart.js/auto'

function ZodiacCard({ sign, onClick }: { sign: ZodiacSign; onClick: () => void }) {
  const bgColorClass = getElementBgColor(sign.element)

  return (
    <button
      onClick={onClick}
      className={`group relative p-5 rounded-2xl border ${bgColorClass} 
        transition-all duration-500 ease-out
        hover:scale-[1.02] hover:shadow-xl hover:-translate-y-1
        active:scale-[0.98] active:translate-y-0`}
    >
      <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      
      <div className="relative">
        <div className="text-4xl mb-3 font-light tracking-tight text-gray-800/90">
          {sign.symbol}
        </div>
        <div className="font-medium text-gray-800 text-[15px] tracking-wide">
          {sign.name}
        </div>
        <div className="text-[11px] text-gray-500 mt-1.5 font-normal tracking-wide">
          {sign.dateRange}
        </div>
        <div className="absolute top-0 right-0">
          <span className="text-[10px] font-medium text-gray-400/80 tracking-wider uppercase">
            {sign.element}
          </span>
        </div>
      </div>
    </button>
  )
}

function RadarChart({ scores, label }: { scores: FortuneScores; label: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const chartRef = useRef<Chart | null>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    if (chartRef.current) {
      chartRef.current.destroy()
    }

    const ctx = canvasRef.current.getContext('2d')
    if (!ctx) return

    const data = {
      labels: ['综合', '爱情', '财富', '工作', '健康'],
      datasets: [{
        label: label,
        data: [scores.all, scores.love, scores.wealth, scores.work, scores.health],
        backgroundColor: 'rgba(251, 191, 36, 0.2)',
        borderColor: 'rgba(251, 191, 36, 0.8)',
        borderWidth: 2,
        pointBackgroundColor: 'rgba(251, 191, 36, 1)',
        pointBorderColor: '#fff',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: 'rgba(251, 191, 36, 1)'
      }]
    }

    chartRef.current = new Chart(ctx, {
      type: 'radar',
      data: data,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          r: {
            angleLines: {
              color: 'rgba(0, 0, 0, 0.1)'
            },
            grid: {
              color: 'rgba(0, 0, 0, 0.05)'
            },
            pointLabels: {
              font: {
                size: 11
              },
              color: 'rgba(0, 0, 0, 0.6)'
            },
            suggestedMin: 0,
            suggestedMax: 100,
            ticks: {
              display: false,
              stepSize: 20
            }
          }
        }
      }
    })

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy()
      }
    }
  }, [scores, label])

  return (
    <div className="w-full h-48">
      <canvas ref={canvasRef} />
    </div>
  )
}

function ZodiacDetail({ sign, onBack }: { sign: ZodiacSign; onBack: () => void }) {
  const [horoscopeData, setHoroscopeData] = useState<HoroscopeData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    fetchHoroscope(sign.id).then(data => {
      setHoroscopeData(data)
      setLoading(false)
    })
  }, [sign.id])

  const bgColorClass = getElementBgColor(sign.element)

  if (loading) {
    return (
      <div className="px-5 py-6">
        <div className="max-w-md mx-auto">
          <BackButton onBack={onBack} />
          <div className={`rounded-3xl p-8 border ${bgColorClass} min-h-[400px] flex items-center justify-center`}>
            <div className="flex flex-col items-center gap-4">
              <div className="w-8 h-8 border-2 border-gray-300/50 border-t-gray-500 rounded-full animate-spin" />
              <span className="text-sm text-gray-400 tracking-wide">加载运势中</span>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!horoscopeData) {
    return (
      <div className="px-5 py-6">
        <div className="max-w-md mx-auto">
          <BackButton onBack={onBack} />
          <div className={`rounded-3xl p-8 border ${bgColorClass}`}>
            <div className="text-center text-gray-500 py-12">
              <p className="text-sm tracking-wide">运势数据加载失败，请稍后重试</p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="px-5 py-6">
      <div className="max-w-md mx-auto">
        <BackButton onBack={onBack} />

        <div className={`rounded-3xl p-6 border ${bgColorClass} mb-5`}>
          <div className="flex items-center gap-5 mb-6">
            <div className="text-5xl font-light text-gray-800/90">{sign.symbol}</div>
            <div>
              <h2 className="text-2xl font-medium text-gray-800 tracking-tight">{sign.name}</h2>
              <p className="text-sm text-gray-500 mt-0.5 tracking-wide">{sign.dateRange}</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-white/70 rounded-xl p-4 border border-white/50">
              <div className="text-[11px] text-gray-400 uppercase tracking-wider mb-2 text-center">今日运势评分</div>
              <RadarChart scores={horoscopeData.scores} label="今日运势" />
            </div>

            {horoscopeData.summary && (
              <div className="bg-white/70 rounded-xl p-4 border border-white/50">
                <div className="text-[11px] text-gray-400 uppercase tracking-wider mb-2">今日概述</div>
                <p className="text-sm text-gray-700 leading-relaxed">{horoscopeData.summary}</p>
              </div>
            )}

            <div className="pt-4 border-t border-gray-200/40">
              <div className="grid grid-cols-3 gap-2">
                {horoscopeData.luckyNumber && (
                  <div className="text-center">
                    <div className="text-[10px] text-gray-400 uppercase tracking-wider">幸运数字</div>
                    <div className="text-lg font-medium text-gray-700 mt-1">{horoscopeData.luckyNumber}</div>
                  </div>
                )}
                {horoscopeData.luckyColor && (
                  <div className="text-center">
                    <div className="text-[10px] text-gray-400 uppercase tracking-wider">幸运颜色</div>
                    <div className="text-sm font-medium text-gray-700 mt-1">{horoscopeData.luckyColor}</div>
                  </div>
                )}
                {horoscopeData.luckyStar && (
                  <div className="text-center">
                    <div className="text-[10px] text-gray-400 uppercase tracking-wider">贵人星座</div>
                    <div className="text-sm font-medium text-gray-700 mt-1">{horoscopeData.luckyStar}</div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function BackButton({ onBack }: { onBack: () => void }) {
  return (
    <button
      onClick={onBack}
      className="mb-5 flex items-center gap-2 text-sm text-gray-400 hover:text-gray-600 transition-colors duration-300 tracking-wide"
    >
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 19l-7-7 7-7" />
      </svg>
      <span>返回星座列表</span>
    </button>
  )
}

export default function Horoscope() {
  const [selectedZodiac, setSelectedZodiac] = useState<ZodiacSign | null>(null)

  if (selectedZodiac) {
    return (
      <PageWrapper title="星座运势">
        <ZodiacDetail sign={selectedZodiac} onBack={() => setSelectedZodiac(null)} />
      </PageWrapper>
    )
  }

  return (
    <PageWrapper title="星座物语">
      <div className="px-5 py-6">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-lg font-medium text-gray-800 tracking-tight mb-2">探索你的星座</h2>
            <p className="text-sm text-gray-400 tracking-wide">选择星座，查看今日运势指引</p>
          </div>

          <div className="grid grid-cols-3 gap-3">
            {zodiacSigns.map(sign => (
              <ZodiacCard
                key={sign.id}
                sign={sign}
                onClick={() => setSelectedZodiac(sign)}
              />
            ))}
          </div>
        </div>
      </div>
    </PageWrapper>
  )
}
